﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace ArcherLai_UnitTestOne
{
    
    class Program
    {
        public bool timerStart;

        static void Main(string[] args)
        {
            Timer time = new System.Timers.Timer(5000);
            time.Elapsed += OnTimeEvent;
            time.AutoReset = true;
            time.Enabled = true;
            

            while (true)
            {
                Console.WriteLine("Choose your question (1-3): ");
                string numbers = Console.ReadLine();
                Console.WriteLine("You have 5 seconds to answer the following question:");
                
                if (numbers == "1")
                {
                    Console.WriteLine("What is your favorite color?");

                    string colors = Console.ReadLine();
                    if (colors == "black")
                    {
                        Console.WriteLine("Well done!");
                    }
                    else
                    {
                        Console.WriteLine("Wrong!  The answer is: black");
                    }
                }

                else if (numbers == "2")
                {
                    Console.WriteLine("What is the answer to life, the universe and everything?");
                    string number = Console.ReadLine();
                    if (number == "42")
                    {
                        Console.WriteLine("Well done!");
                    }
                    else
                    {
                        Console.WriteLine("Wrong!  The answer is: 42");
                    }

                }

                else if (numbers == "3")
                {
                    Console.WriteLine("What is the airspeed velocity of an unladen swallow ?");
                    string mean = Console.ReadLine();
                    if (mean == "What do you mean? African or European swallow?")
                    {
                        Console.WriteLine("Well done!");
                    }
                    else
                    {
                        Console.WriteLine("Wrong!  The answer is: What do you mean? African or European swallow ?");
                    }
                }
                Console.WriteLine("Play again?");
                string yesOrno = Console.ReadLine();
                if (yesOrno == "yes")
                {
                    continue;
                }
                else
                {
                    break;
                }
            }                      
        }
        public void OnTimeEvent(Object source, ElapsedEventArgs e)
        {
            timerStart = true;
        }
    }
}
